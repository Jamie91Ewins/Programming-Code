function love.load()
	love.graphics.setMode(1400, 700, false, true, 16)
	world = love.physics.newWorld(0, 200, true)
        world:setCallbacks(beginContact, endContact, preSolve, postSolve)

	mario = {}
        	mario.b = love.physics.newBody(world, 400,200, "dynamic")--set position of object
        	--mario.b:setMass(500)
        	mario.s = love.physics.newRectangleShape(10,5)--set size of object
		mario.i = love.graphics.newImage("mario.png")
        	mario.f = love.physics.newFixture(mario.b, mario.s)
        	--mario.f:setRestitution(0.10)    -- make it bouncy
        	mario.f:setUserData("mario")

	donkeyKong = {}
        	donkeyKong.b = love.physics.newBody(world, 150,50, "dynamic")--set position of object
        	donkeyKong.s = love.physics.newRectangleShape(50,60)--set size of object
		donkeyKong.i = love.graphics.newImage("donkeyKong.jpg")
        	donkeyKong.f = love.physics.newFixture(donkeyKong.b, donkeyKong.s)
        	donkeyKong.f:setUserData("donkeyKong")

	block = {}
        	block.b = love.physics.newBody(world, 400,555, "static")--set position of object
        	block.s = love.physics.newRectangleShape(447,43)--set size of object
			block.i = love.graphics.newImage("block.png")
        	block.f = love.physics.newFixture(block.b, block.s)
        	block.f:setUserData("Block")

	block1 = {}
        	block1.b = love.physics.newBody(world, 550,700, "static") --set position of object
        	block1.s = love.physics.newRectangleShape(0,0)--set size of object
		block1.i = love.graphics.newImage("block.png")
        	block1.f = love.physics.newFixture(block1.b, block1.s)
        	block1.f:setUserData("Block1")

	block2 = {}
        	block2.b = love.physics.newBody(world, 550,450, "static") --set position of object
        	block2.s = love.physics.newRectangleShape(795,50)--set size of object
		block2.i = love.graphics.newImage("block.png")
        	block2.f = love.physics.newFixture(block2.b, block2.s)
        	block2.f:setUserData("Block2")

	block3 = {}
        	block3.b = love.physics.newBody(world, 125,200, "static") --set position of object
        	block3.s = love.physics.newRectangleShape(795,50)--set size of object
		block3.i = love.graphics.newImage("block.png")
        	block3.f = love.physics.newFixture(block3.b, block3.s)
        	block3.f:setUserData("Block3")

	barrel = {}
		barrel.b = love.physics.newBody(world, 500,500, "dynamic") --set position of object
		barrel.s = love.physics.newRectangleShape(50,50) --set size of object
		barrel.i = love.graphics.newImage("starBarrel.png")
		barrel.f = love.physics.newFixture(barrel.b,barrel.s)
		barrel.f:setUserData("Barrel")
		
	text       = ""   -- we'll use this to put info text on the screen later
    persisting = 0    -- we'll use this to store the state of repeated callback calls

end

function love.update(dt)
	world:update(dt)

	if love.keyboard.isDown("right") then
        mario.b:applyForce(50, 0)
    elseif love.keyboard.isDown("left") then
        mario.b:applyForce(-50, 0)
    elseif love.keyboard.isDown("up") then
        mario.b:applyForce(0, -50)
   end
end

function love.draw()
	love.graphics.draw(barrel.i,barrel.b:getX(), barrel.b:getY())
	love.graphics.draw(donkeyKong.i,donkeyKong.b:getX(), donkeyKong.b:getY())
	love.graphics.draw(mario.i, mario.b:getX(),mario.b:getY())
	love.graphics.draw(block.i, block.b:getX(),block.b:getY())
	love.graphics.draw(block1.i, block1.b:getX(),block1.b:getY())
	love.graphics.draw(block2.i, block2.b:getX(),block2.b:getY())
	love.graphics.draw(block3.i, block3.b:getX(),block3.b:getY())
	love.graphics.print(text, 10, 10)
end

 function beginContact(a, b, coll)
     x,y = coll:getNormal()
     text = text.."\n"..a:getUserData().." colliding with "..b:getUserData().." with a vector normal of: "..x..", "..y
	 end

function endContact(a, b, coll)
    persisting = 0
    text = text.."\n"..a:getUserData().." uncolliding with "..b:getUserData()
 end

 function preSolve(a, b, coll)
     if persisting == 0 then    -- only say when they first start touching
        text = text.."\n"..a:getUserData().." touching "..b:getUserData()
     elseif persisting < 20 then    -- then just start counting
        text = text.." "..persisting
     end
    persisting = persisting + 1    -- keep track of how many updates they've been touching for
 end

 function postSolve(a, b, coll)
end



--[[function love.load()
    world = love.physics.newWorld(0, 200, true)
        world:setCallbacks(beginContact, endContact, preSolve, postSolve)

	mario = {}
        mario.b = love.physics.newBody(world, 400,200, "dynamic")
        mario.b:setMass(10)
        mario.s = love.physics.newCircleShape(50)
        mario.f = love.physics.newFixture(mario.b, mario.s)
        mario.f:setRestitution(0.4)    -- make it bouncy
        mario.f:setUserData("mario")

donkeyKong = {}
        donkeyKong.b = love.physics.newBody(world, 200,200, "dynamic")
        donkeyKong.b:setMass(10)
        donkeyKong.s = love.physics.newCircleShape(50)
        donkeyKong.f = love.physics.newFixture(donkeyKong.b, donkeyKong.s)
        donkeyKong.f:setRestitution(0.4)    -- make it bouncy
        donkeyKong.f:setUserData("donkeyKong")
    block = {}
        block.b = love.physics.newBody(world, 400,400, "block")
        block.s = love.physics.newRectangleShape(700,50)
        block.f = love.physics.newFixture(block.b, block.s)
        block.f:setUserData("Block")

	barrel = {}
		barrel.b = love.physics.newBody(world, 400,400, "dynamic")
		barrel.b:setMass(10)
        barrel.s = love.physics.newCircleShape(50)
		--barrel.s=love.graphics.newImage("StarBarrel.png")
		barrel.f = love.physics.newFixture(barrel.b, barrel.s)
		barrel.f:setUserData("barrel")

    text       = ""   -- we'll use this to put info text on the screen later
    persisting = 0    -- we'll use this to store the state of repeated callback calls
end

function love.update(dt)
    world:update(dt)

    if love.keyboard.isDown("right") then
        mario.b:applyForce(1000, 0)
    elseif love.keyboard.isDown("left") then
        mario.b:applyForce(-1000, 0)
    end
    if love.keyboard.isDown("up") then
        mario.b:applyForce(0, -5000)
    elseif love.keyboard.isDown("down") then
        mario.b:applyForce(0, 1000)
    end

    if string.len(text) > 768 then    -- cleanup when 'text' gets too long
        text = ""

    end
end

--function on.paint(gc)
	--gc:drawImage(Barrel,0,0)
--end


function love.draw()
    love.graphics.circle("line", mario.b:getX(),mario.b:getY(), mario.s:getRadius(), 20)
	love.graphics.circle("line", donkeyKong.b:getX(),donkeyKong.b:getY(), donkeyKong.s:getRadius(), 20)
    love.graphics.polygon("line", block.b:getWorldPoints(block.s:getPoints()))
	love.graphics.draw("barrel", barrel.b:getX(),barrel.b:getY(),barrel.s:getRadius(), 20)
    love.graphics.print(text, 10, 10)
end

function beginContact(a, b, coll)
    x,y = coll:getNormal()
    text = text.."\n"..a:getUserData().." colliding with "..b:getUserData().." with a vector normal of: "..x..", "..y
end

function endContact(a, b, coll)
    persisting = 0
    text = text.."\n"..a:getUserData().." uncolliding with "..b:getUserData()
end

function preSolve(a, b, coll)
    if persisting == 0 then    -- only say when they first start touching
        text = text.."\n"..a:getUserData().." touching "..b:getUserData()
    elseif persisting < 20 then    -- then just start counting
        text = text.." "..persisting
    end
    persisting = persisting + 1    -- keep track of how many updates they've been touching for
end

function postSolve(a, b, coll)
end--]]
